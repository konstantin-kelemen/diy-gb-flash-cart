// Single-operation MX29LV320E x8 sequencer. Defaults are for 2.08 MHz.
// The block target supplies timers and bus ticks for 53.20 MHz.
// Commands: 10 read, 11 program byte, 12 sector erase, 13 ID, 14 reset.
// Ð’Ð»Ð°Ð´ÐµÐ½Ð¸Ðµ ÑˆÐ¸Ð½Ð¾Ð¹ Ð·Ð°Ð´Ð°Ñ‘Ñ‚ÑÑ target; SPLIT_DATA Ð¸ÑÐ¿Ð¾Ð»ÑŒÐ·ÑƒÐµÑ‚ÑÑ Ñ Ð²Ð½ÐµÑˆÐ½Ð¸Ð¼ Ð°Ñ€Ð±Ð¸Ñ‚Ñ€Ð¾Ð¼.
module mx29_programmer #(
    parameter POWER_CYCLES = 520000,
    parameter PROGRAM_CYCLES = 4160,
    parameter ERASE_CYCLES = 6240000,
    parameter READ_TICKS = 1, WRITE_TICKS = 1, SPLIT_DATA = 0
) (
    input wire clk, reset, start,
    input wire [7:0] command,
    input wire [21:0] address,
    input wire [7:0] data,
    output wire busy,
    output reg done,
    output reg [7:0] status,
    output reg [15:0] result,
    output wire [21:0] flash_a,
    inout wire [7:0] flash_d,
    output wire flash_ce_n, flash_oe_n, flash_we_n,
    output wire fram_ce_n, fram_oe_n, fram_we_n,
    input wire [7:0] memory_data_in,
    output wire [7:0] memory_data_out,
    output wire memory_data_drive
);
    localparam POWER=0, IDLE=1, ISSUE=2, WAIT_BUS=3,
               POLL=4, WAIT_POLL=5, RESET_FLASH=6, WAIT_RESET=7,
               VERIFY=8, WAIT_VERIFY=9;
    reg [3:0] state;
    reg [2:0] step;
    reg [1:0] op; // Low bits of the already validated 10h..13h command.
    reg [7:0] value;
    reg [21:0] target;
    reg [27:0] timer;
    reg recheck;
    reg fram;
    wire bus_ce_n, bus_oe_n, bus_we_n;
    assign flash_ce_n=fram ? 1'b1 : bus_ce_n;
    assign flash_oe_n=fram ? 1'b1 : bus_oe_n;
    assign flash_we_n=fram ? 1'b1 : bus_we_n;
    assign fram_ce_n=fram ? bus_ce_n : 1'b1;
    assign fram_oe_n=fram ? bus_oe_n : 1'b1;
    assign fram_we_n=fram ? bus_we_n : 1'b1;
    reg bus_start, bus_write;
    reg [21:0] bus_addr;
    reg [7:0] bus_data;
    wire bus_done;
    wire [7:0] bus_result;
    assign busy = state != IDLE;
    mx29_bus #(.READ_TICKS(READ_TICKS), .WRITE_TICKS(WRITE_TICKS), .SPLIT_DATA(SPLIT_DATA)) bus(.clk(clk), .reset(reset), .start(bus_start),
        .write_cycle(bus_write), .addr(bus_addr), .wdata(bus_data),
        .busy(), .done(bus_done), .rdata(bus_result),
        .flash_a(flash_a), .flash_d(flash_d), .flash_ce_n(bus_ce_n),
        .flash_oe_n(bus_oe_n), .flash_we_n(bus_we_n),
        .memory_data_in(memory_data_in), .memory_data_out(memory_data_out), .memory_data_drive(memory_data_drive));

    always @(posedge clk) begin
        if (reset) begin
            state <= POWER; timer <= POWER_CYCLES; done <= 0; status <= 0;
            result <= 0; step <= 0; op <= 0; value <= 0; target <= 0;
            fram <= 0; recheck <= 0; bus_start <= 0; bus_write <= 0;
            bus_addr <= 0; bus_data <= 0;
        end else begin
            bus_start <= 0;
            done <= 0;
            // Load the deadline once; a zero detector replaces wide comparisons.
            if ((state == POLL || state == WAIT_POLL) && timer != 0)
                timer <= timer - 1'b1;
            case (state)
                POWER: if (timer == 0) state <= IDLE;
                       else timer <= timer - 1'b1;
                IDLE: if (start) begin
                    fram <= command==8'h16 || command==8'h17;
                    op <= (command==8'h16 || command==8'h17) ? {1'b0,command[0]} : command[1:0]; target <= address; value <= data;
                    result <= 0; status <= 0; step <= 0; recheck <= 0;
                    if (command == 8'h14) state <= RESET_FLASH;
                    else if (command==8'h16 || command==8'h17) state <= ISSUE;
                    else if (command >= 8'h10 && command <= 8'h13) state <= ISSUE;
                    else begin status <= 8'h02; done <= 1; end
                end
                ISSUE: begin
                    bus_start <= 1;
                    bus_write <= 1;
                    bus_addr <= 22'h000aaa;
                    bus_data <= 8'haa;
                    if (fram) begin
                        bus_write <= op[0]; bus_addr <= target; bus_data <= value;
                    end else if (op == 2'd0) begin
                        bus_write <= 0; bus_addr <= target;
                    end else case (step)
                        0: begin end
                        1: begin bus_addr <= 22'h000555; bus_data <= 8'h55; end
                        2: bus_data <= op == 2'd1 ? 8'ha0 : op == 2'd2 ? 8'h80 : 8'h90;
                        3: if (op == 2'd1) begin bus_addr <= target; bus_data <= value; end
                           else if (op == 2'd3) begin bus_write <= 0; bus_addr <= 0; end
                        4: if (op == 2'd3) begin bus_write <= 0; bus_addr <= 2; end
                           else begin bus_addr <= 22'h000555; bus_data <= 8'h55; end
                        5: begin bus_addr <= target; bus_data <= 8'h30; end
                        default: begin end
                    endcase
                    state <= WAIT_BUS;
                end
                WAIT_BUS: if (bus_done) begin
                    if (fram) begin
                        if(op[0]) state <= VERIFY;
                        else begin result <= {8'b0,bus_result}; done <= 1; state <= IDLE; end
                    end else if (op == 2'd0) begin
                        result <= {8'b0, bus_result}; done <= 1; state <= IDLE;
                    end else if (op == 2'd3 && step == 4) begin
                        result[15:8] <= bus_result; state <= RESET_FLASH;
                    end else if ((op == 2'd1 && step == 3) || (op == 2'd2 && step == 5)) begin
                        timer <= op == 2'd2 ? ERASE_CYCLES : PROGRAM_CYCLES; state <= POLL;
                    end else begin
                        if (op == 2'd3 && step == 3) result[7:0] <= bus_result;
                        step <= step + 1'b1; state <= ISSUE;
                    end
                end
                POLL: begin
                    bus_start <= 1; bus_write <= 0; bus_addr <= target;
                    state <= WAIT_POLL;
                end
                WAIT_POLL: if (bus_done) begin
                    // Datasheet Fig. 20: re-read Q7 if Q5 becomes set.
                    if (bus_result[7] == (op == 2'd2 ? 1'b1 : value[7]))
                        state <= VERIFY;
                    else if (recheck) begin status <= 8'h04; state <= RESET_FLASH; end
                    else if (timer == 0) begin
                        status <= 8'h03; state <= RESET_FLASH;
                    end else begin recheck <= bus_result[5]; state <= POLL; end
                end
                VERIFY: begin
                    bus_start <= 1; bus_write <= 0; bus_addr <= target;
                    state <= WAIT_VERIFY;
                end
                WAIT_VERIFY: if (bus_done) begin
                    result <= {8'b0, bus_result};
                    if (bus_result != (op == 2'd2 ? 8'hff : value)) status <= 8'h05;
                    if(fram) begin done <= 1; state <= IDLE; end
                    else state <= RESET_FLASH;
                end
                RESET_FLASH: begin
                    bus_start <= 1; bus_write <= 1; bus_addr <= 0; bus_data <= 8'hf0;
                    state <= WAIT_RESET;
                end
                WAIT_RESET: if (bus_done) begin done <= 1; state <= IDLE; end
                default: begin status <= 8'h06; state <= RESET_FLASH; end
            endcase
        end
    end
endmodule
