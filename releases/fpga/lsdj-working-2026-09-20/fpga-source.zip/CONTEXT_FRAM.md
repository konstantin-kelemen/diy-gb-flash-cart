# CONTEXT.md

## Project

Custom original Game Boy cartridge for LSDj.

Hardware:

- Original Nintendo Game Boy
- FPGA: Lattice MachXO2-1200HC, TQFP-100
- ROM Flash: Macronix MX29LV320E, 4 MiB, x8
- Save memory: FM28V100, 128 KiB parallel FRAM
- USB/programmer: RP2040-Zero
- Level shifting: SN74LVC8T245
- Mapper: FPGA MBC5-compatible
- Goal: LSDj cartridge with 4 MiB ROM + 128 KiB nonvolatile save RAM + USB programming

Flash and FRAM share the FPGA address/data bus. FRAM has separate CE/OE/WE controls.

---

## CURRENT STATUS

The cartridge is now functionally working.

After replacing the FRAM chip again:

- the deterministic FRAM failure at bank `E`, address `A3EB` disappeared
- generic FRAM diagnostics pass
- the LSDj-like SRAM diagnostic no longer reproduces the previous failure
- **LSDj 9.4.2 successfully booted on the real Game Boy for the first time**

This is currently the strongest evidence that the previous failures were caused by bad/problematic FRAM chips, not by a fundamental MBC5/FPGA/PCB design error.

Do not make broad FPGA/mapper changes unless a new reproducible failure appears.

---

## FRAM source / quality concern

The FM28V100 chips were bought from AliExpress.

Listing shown by the user:

```text
Seller/listing branding: Mxsyuan electronics
Part marking shown: RAMTRON FM28V100-TG
Quantity: 5 pcs
Price: approximately €25 total
=> about €5 per chip
```

Example marking from the listing image:

```text
RAMTRON
FM28V100-TG
A1633176TG1
2235 TAIWAN
```

Several chips from this batch behaved suspiciously:

- one FRAM showed persistent failures in a specific bank region
- replacing FRAM did not immediately solve all issues
- another replacement later removed the deterministic `E:A3EB` failure
- after the latest replacement, LSDj finally booted

This does not prove counterfeit parts, but strongly suggests inconsistent chip quality, salvaged/reworked stock, damaged parts, or otherwise unreliable components.

For the final revision, use at least one known-good FM28V100 from an authorized distributor as a control.

---

## Soldering / device robustness notes

FM28V100 is not known as an unusually fragile part under normal soldering.

Relevant practical points:

- normal lead-free reflow peak is around 260 °C
- package is MSL3, so moisture exposure before heating can matter
- prolonged hand heating, multiple rework cycles, ESD, or moisture-related package damage can still hurt the device
- however, repeated address-specific failures across cheap AliExpress parts make component quality/source more suspicious than normal soldering alone

---

## Important hardware facts

Known FPGA/address assignments:

```text
flash_a[10] -> SITE 16
flash_a[13] -> SITE 19
flash_a[14] -> SITE 20
flash_a[15] -> SITE 21
flash_a[16] -> SITE 24

fram_ce_n -> SITE 82
fram_oe_n -> SITE 83
fram_we_n -> SITE 84
```

Flash and FRAM share:

```text
flash_a[16:0]
flash_d[7:0]
```

Physical continuity previously verified:

```text
SITE 19 -> FRAM A13
SITE 20 -> FRAM A14
SITE 21 -> FRAM A15
SITE 24 -> FRAM A16
```

Correct FM28V100 TSOP-32 pinout used during debugging:

```text
1  A11
2  A9
3  A8
4  A13
5  /WE
6  CE2
7  A15
8  VDD
9  NC/reserved
10 A16
11 A14
12 A12
13 A7
14 A6
15 A5
16 A4
17 A3
18 A2
19 A1
20 A0
21 DQ0
22 DQ1
23 DQ2
24 VSS
25 DQ3
26 DQ4
27 DQ5
28 DQ6
29 DQ7
30 /CE1
31 A10
32 /OE
```

---

## FPGA / mapper architecture

Relevant MBC5 behavior:

```text
0000-1FFF write: RAM enable, low nibble == A
2000-2FFF write: ROM bank bits 0-7
3000-3FFF write: ROM bank bit 8
4000-5FFF write: RAM bank bits 0-3
A000-BFFF: external RAM window
```

RAM mapping:

```verilog
ram_bank = rumble
    ? {1'b0, ram_select[2:0]}
    : ram_select[3:0];

ram_address = {ram_bank, gb_a[12:0]} & ram_mask;
```

For RAM size header byte `0x04`:

```verilog
ram_mask = 17'h1ffff;
```

which maps all 128 KiB.

Relevant shared bus structure:

```verilog
assign flash_d =
    programmer_enable && programmer_memory_drive ? programmer_memory_data :
    game_enable && game_memory_drive ? game_memory_data :
    8'hzz;

assign flash_a =
    programmer_enable ? programmer_address :
    game_enable ? game_address :
    22'b0;

assign fram_ce_n = game_enable ? game_ram_ce_n : 1'b1;
assign fram_oe_n = game_enable ? game_ram_oe_n : 1'b1;
assign fram_we_n = game_enable ? game_ram_we_n : 1'b1;
```

---

## Current `cart_mapper.v`

Several experimental versions were tried during debugging:

1. direct mapper updates on Game Boy `/WR`
2. synchronized `/WR` into FPGA 53.2 MHz domain
3. a more aggressive whole-bus capture variant

The aggressive capture variant made behavior worse and was reverted.

The current working baseline is the previously stable user-modified mapper, believed to include:

- `clk` input
- registered cartridge header decode / mapper type
- registered RAM masks and `supported_config`
- synchronized `/WR`
- one mapper update per detected write pulse

**Do not refactor this working mapper just because older diagnostics once failed.**

First preserve the exact working HDL in git.

---

## LSDj ROM

ROM under test:

```text
lsdj9_4_2.gb
```

Header bytes:

```text
0147 = 1B
0148 = 05
0149 = 04
```

Interpretation:

```text
1B = MBC5 + RAM + battery
05 = 1 MiB ROM
04 = 128 KiB RAM
```

Thus LSDj correctly declares the full 128 KiB RAM.

Earlier speculation that LSDj declared only 32 KiB RAM was false.

---

## Historical deterministic FRAM failure

Before the latest FRAM replacement, the custom LSDj-like diagnostic repeatedly failed at:

```text
FIRST FAILURE

PHASE: 2
BANK:  0E
ADDR:  A3EB
EXP:   00
GOT:   04
READ:  1
```

Physical mapping:

```text
bank E base = 0xE * 0x2000 = 0x1C000
offset A3EB-A000 = 0x03EB
physical FRAM address = 0x1C3EB
```

External FRAM dump after the failure showed:

```text
0x1C3EB = 0x04
```

A later fresh dump was identical.

This proved that the intended write of `00` to physical FRAM `0x1C3EB` had not persisted.

After replacing FRAM again, this failure disappeared without a corresponding FPGA/PCB redesign.

Therefore this historical failure is now best treated as evidence of a bad/problematic FRAM device, not proof of a mapper/timing bug.

---

## Targeted FRAM diagnostic ROM

A targeted ROM was created from `main.asm`.

Purpose:

- bank E
- addresses A3EA / A3EB
- several patterns
- immediate and delayed readback

Patterns:

```text
00
FF
55
AA
04
FB
E3
```

The problematic FRAM produced results such as:

```text
00 -> 04
AA -> 1E
FB -> FF
E3 -> E7
```

Immediate and delayed reads often matched the same wrong value.

That made a simple "read too soon after write" explanation unlikely.

After replacing FRAM again, the overall problem disappeared.

---

## Earlier hardware debugging

Before the final successful FRAM replacement, the board had several genuine physical connection issues.

After those were repaired:

```text
fram_data_bus_diag_v2.gb:
10 consecutive cold runs PASS

fram_mbc5_diag_nop3.gb:
10 consecutive runs PASS

fram_mbc5_diag.gb:
PASS
```

This already showed that:

- MBC5 RAM enable works
- RAM bank selection works
- ordinary reads/writes work
- all 128 KiB are addressable
- the shared data bus works

The remaining LSDj-specific failure persisted until FRAM was replaced again.

---

## Previous FRAM-specific history

At an earlier stage, a FRAM chip exhibited:

```text
forced bank test:

PASS: 0,1,4,5,6,7,8,9,A,B,C,D,E,F
FAIL: 2,3
```

That looked like a localized physical memory region failure.

The chip was replaced.

The issue evolved across replacements, and the final replacement eventually removed the current deterministic error completely.

This repeated pattern is an important reason to distrust the AliExpress batch.

---

## Physical checks already performed

After the deterministic A3EB issue, the board was re-checked.

Checked:

- address lines
- lower address lines A0/A1/A2/A3
- upper address lines relevant to bank E
- FRAM control lines
- data bus
- shorts / unintended continuity

No obvious connection problems were found.

Then FRAM was replaced again.

After replacement, the problem disappeared and LSDj booted.

This is the strongest A/B test available so far.

---

## Important false leads / things not to repeat

### "FRAM A14 is shorted"

In-circuit resistance readings were misleading because the address bus is connected to multiple devices. No definitive short was proven.

### "The FPGA A14 output cell is bad"

A14/A15 assignments were experimentally swapped earlier and the failure remained. This did not identify an FPGA pin defect.

### "Flash programming is broken"

Flash erase/program/verify works. Reprogramming ROM did not solve the FRAM issue.

### "LSDj declares too little RAM"

False. Current LSDj ROM declares 128 KiB.

### "Immediate write -> read timing is definitely the cause"

Not supported by the final evidence.

The bad FRAM returned persistent wrong values after delay and still contained the wrong values in an external dump.

The issue disappeared after FRAM replacement.

### "Mapper needs another redesign"

Do not do this unless a new reproducible failure proves the mapper is at fault.

The current mapper boots LSDj.

---

## RP2040 status

RP2040 <-> FPGA SPI communication was previously brought up successfully.

After wiring correction:

```text
RX: 00 47 42 46 43 01 00 00 00
OK: FPGA protocol 1.0, capabilities=0x0000

TEST: total=1000 pass=1000 fail=0 elapsed=8500 ms
PASS
```

So the communication link is already proven.

---

## Recommended immediate next steps

### 1. Freeze the working baseline

Create a clean git commit/tag containing exactly the working:

```text
top.v
game_multi_core.v
cart_mapper.v
game_programmer.lpf
other FPGA sources
```

Suggested tag:

```text
lsdj-working-baseline
```

### 2. Validate FRAM persistence in real LSDj

In LSDj:

1. create or edit a song/project
2. save/modify enough data to exercise SRAM
3. power off Game Boy
4. wait several minutes
5. power on
6. verify data survives
7. repeat several cold cycles

### 3. Final confidence run

Suggested:

```text
fram_data_bus_diag_v2.gb   10x
fram_mbc5_diag.gb          10x
lsdj_sram_diag.gb          3-5x
LSDj built-in SRAM test    3-5x
LSDj cold boot             5-10x
```

If all pass, stop debugging the memory interface.

### 4. Move to USB programmer functionality

Next milestone:

```text
USB
 ↓
RP2040
 ↓
FPGA bus ownership / arbitration
 ↓
Flash / FRAM
```

Suggested order:

#### First: FRAM backup/restore

Implement:

```text
read full 128 KiB FRAM
write full 128 KiB FRAM
verify FRAM
save to file
restore from file
```

#### Then: Flash programming

Implement:

```text
read Flash
erase Flash
program ROM
verify ROM
```

### 5. Safe GB/USB bus ownership

Ensure Game Boy and programmer can never actively drive the same bus at the same time.

Required behavior:

```text
Game Boy active:
  programmer memory drive disabled
  programmer cannot assert memory control lines

USB programming active:
  GB-facing outputs isolated / Hi-Z as appropriate
  programmer owns Flash/FRAM bus
```

Safe defaults during FPGA configuration/reset:

```text
Flash /CE inactive
FRAM /CE1 inactive
/WE inactive
/OE inactive
data bus Hi-Z unless intentionally driven
```

### 6. Final PCB revision

After firmware/programmer flow is stable:

- keep the working topology
- add test points for A0/A1/A2, A13-A16, DQ0-DQ7, /CE1, /OE, /WE, CE2, 3V3, GND
- make FRAM soldering easier to inspect
- preserve good decoupling
- document bus ownership clearly
- use authorized-source FRAM for final units

---

## Suggested test for remaining AliExpress FRAM chips

Before installing another chip from the same batch, test all 131072 bytes with multiple patterns:

```text
00
FF
55
AA
33
CC
walking 1
walking 0
address-derived pattern
LFSR/pseudorandom pattern
```

For each pattern:

```text
write entire FRAM
read entire FRAM
compare every byte
record first bad address
record total error count
```

Also repeat after power cycle.

If loose chips fail before soldering, that strongly confirms a bad batch.

---

## Known useful files / artifacts

Project/source:

```text
top.v
game_multi_core.v
cart_mapper.v
game_programmer.lpf
cartridge.kicad_sch
PINOUT.md
```

Diagnostics:

```text
fram_data_bus_diag_v2.gb
fram_mbc5_diag.gb
fram_mbc5_diag_nop3.gb
lsdj_sram_diag.gb
main.gb
```

LSDj:

```text
lsdj9_4_2.gb
```

Historical FRAM dump:

```text
fram-test2.bin
```

Targeted test source:

```text
main.asm
```

---

## Current strongest conclusions

As of the latest successful test:

```text
Game Boy -> FPGA path: working
ROM Flash: working
MBC5 ROM banking: working
MBC5 RAM banking: working
128 KiB FRAM mapping: working
generic FRAM diagnostics: working
LSDj ROM header: correct
RP2040 <-> FPGA SPI: working
LSDj 9.4.2: BOOTS SUCCESSFULLY
```

The previous deterministic SRAM failure disappeared after another FRAM replacement.

Current primary hypothesis:

```text
bad / inconsistent FM28V100 chips from the AliExpress batch
```

rather than:

```text
fundamental mapper bug
PCB address mapping bug
generic write/read timing bug
```

Treat the current hardware + HDL combination as the new known-good baseline.

---

## Next project milestone

The cartridge core functionality is proven.

Next:

```text
RP2040 USB save backup/restore
```

then:

```text
RP2040 USB Flash erase/program/verify
```

then:

```text
final PCB revision + known-good sourced FRAM
```
