# Waveshare RP2040-Zero - KiCad 10

Native KiCad 10 reconstruction of the Waveshare RP2040-Zero schematic, now with component footprints assigned.

Files:
- `RP2040_Zero.kicad_sch` - KiCad 10 schematic with footprint assignments.
- `RP2040_Zero.kicad_sym` - project-local symbol library.
- `RP2040_Zero_Footprints.pretty/` - local footprints for the Winbond USON flash, USB-C connector, and photo-matched tactile switches.
- `sym-lib-table` / `fp-lib-table` - project-local library mappings.
- `RP2040_Zero.kicad_pro` - project file.
- `FOOTPRINT_AUDIT.md` - footprint-by-footprint evidence and confidence notes.

Source schematic: https://files.waveshare.com/upload/4/4c/RP2040_Zero.pdf

Important: L1 is intentionally left without a footprint because the visible 2x2 mm LED package is clear but its published WS2812B-2020 pad numbering conflicts with the source schematic's pin numbering. Verify the fitted LED/continuity before assigning L1.

P1/P2/P3 are logical representations of the module PCB's own castellated/solder pads, not discrete headers, so they intentionally have no generic header footprint. Reconstruct those pads as custom PCB geometry when laying out the board.
